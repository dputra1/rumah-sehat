package apap.TA_C_SA_88.RumahSehat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RumahSehatApplication {

	public static void main(String[] args) {
		SpringApplication.run(RumahSehatApplication.class, args);
	}

}
