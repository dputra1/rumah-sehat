package apap.TA_C_SA_88.RumahSehat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RumahSehatApplicationTests {

	@Test
	void contextLoads() {
	}

}
